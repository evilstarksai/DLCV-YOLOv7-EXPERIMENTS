# kapilproject > 2023-01-10 1:49pm
https://universe.roboflow.com/solinas-xml-to-txt/kapilproject

Provided by a Roboflow user
License: CC BY 4.0

